import UIKit

var greeting = "Hello, playground"


print (greeting)

var name = "Jason"
name = "Amy"

var weight = 100
var AdditionalWeight = 50
weight = weight + AdditionalWeight


var age: Int = 10
age = Int(5.3)
